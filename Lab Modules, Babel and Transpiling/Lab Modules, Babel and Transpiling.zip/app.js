/**
 * Created by Stoyan on 15.7.2017 г..
 */
let Person = require('./PersonModule');

result.Person = Person;
