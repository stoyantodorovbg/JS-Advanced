/**
 * Created by Stoyan on 15.7.2017 г..
 */
let mapSort = require('./helper-functions');

result.mapSort = mapSort;
//let map = new Map();
//map.set(3,"Pesho");
//map.set(1,"Gosho");//
//map.set(7,"Aleks");
//console.log(map)
//console.log(mapSort(map, 'ValuesStringsAsc'));